function light(num)
		{
			if(num==4)
			{
			document.getElementById("i1").style.backgroundColor="salmon";
			}
			else
				{
					document.getElementById("i1").style.backgroundColor="Springgreen";
				}
		}
		
				function color(num)
		{
			if(num==6)
			{
			document.getElementById("i1").style.backgroundColor="Rosybrown";
			}
			else
				{
					document.getElementById("i1").style.backgroundColor="Teal";
				}
		}

function Square()
		{
			num = document.getElementById("Number").value;
			var x=num;
			document.getElementById("result").innerHTML=x**2;
		}

		function Cube() 
		{ 
			num = document.getElementById("Number").value;
			var x=num;
			document.getElementById("result").innerHTML=x**3;
		}		